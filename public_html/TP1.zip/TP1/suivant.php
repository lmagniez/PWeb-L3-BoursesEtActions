<?php
phpinfo()
?>



